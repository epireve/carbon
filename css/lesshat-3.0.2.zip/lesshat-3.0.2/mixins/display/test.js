var assert = require('assert');

describe('display', function () {

  /**
   * If you want to test this code, comment 'prefixed:false' from display.js
   */
  // it('should prefix and return value', function (done) {
  //   test.display.webkit('flex', '-webkit-flex', done);
  // });

  // it('should prefix and return value', function (done) {
  //   test.display.oldwebkit('flex', '-webkit-box', done);
  // });

});