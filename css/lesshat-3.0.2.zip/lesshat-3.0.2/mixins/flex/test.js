var assert = require('assert');

describe('flex', function () {

  /**
   * If you want to test this code, comment 'flex.result' from flex.js
   */
  // it('should return first value', function (done) {
  //   test.flex.moz('1 3 100px', '1', done);
  // });

});
