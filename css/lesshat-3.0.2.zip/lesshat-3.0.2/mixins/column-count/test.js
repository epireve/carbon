var assert = require('assert');

describe('column-count', function() {

  it('should return the same value ', function(done) {
    test.columnCount('3', '3', done);
  });

});