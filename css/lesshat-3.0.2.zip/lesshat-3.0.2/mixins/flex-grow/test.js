var assert = require('assert');

describe('flex-grow', function () {

  it('should return the same value', function (done) {
    test.flexGrow('2', '2', done);
  });

});