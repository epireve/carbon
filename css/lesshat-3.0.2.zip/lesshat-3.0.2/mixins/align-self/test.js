var assert = require('assert');

describe('align-self', function () {

  /**
   * If you want to test this code, comment 'alignSelf.result' from align-self.js
   */
  //it('should return start', function (done) {
  //  test.alignSelf.ms('flex-start', 'start', done);
  //});

});
